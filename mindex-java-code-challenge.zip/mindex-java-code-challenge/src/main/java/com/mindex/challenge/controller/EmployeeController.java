package com.mindex.challenge.controller;

import com.mindex.challenge.data.Employee;
import com.mindex.challenge.service.EmployeeService;
import com.mindex.challenge.data.ReportingStructure; //AV
import com.mindex.challenge.data.Compensation;     //AV
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class EmployeeController {
    private static final Logger LOG = LoggerFactory.getLogger(EmployeeController.class);

    @Autowired
    private EmployeeService employeeService;

    @PostMapping("/employee")
    public Employee create(@RequestBody Employee employee) {
        LOG.debug("Received employee create request for [{}]", employee);

        return employeeService.create(employee);
    }

    @GetMapping("/employee/{id}")
    public Employee read(@PathVariable String id) {
        LOG.debug("Received employee create request for id [{}]", id);

        return employeeService.read(id);
    }

    @PutMapping("/employee/{id}")
    public Employee update(@PathVariable String id, @RequestBody Employee employee) {
        LOG.debug("Received employee create request for id [{}] and employee [{}]", id, employee);

        employee.setEmployeeId(id);
        return employeeService.update(employee);
    }

    //AV adding the mapping for the new calculate employee results endpoint
    @GetMapping("/employeeReports/{id}")
    public ReportingStructure directReports(@PathVariable String id){
        LOG.debug("Recieved generate direct reports request for id [{}]", id);
        return employeeService.directReports(id);
    }

    //AV task 2
    @GetMapping("/compensation/{id}")
    public Compensation readComp(@PathVariable String id) {
        LOG.debug("Received compensation read request for id [{}]", id);
        return employeeService.readComp(id);
    }

    @PostMapping("/compensation/{salary}+{date}")
    public Compensation createComp(@RequestBody Employee employee, @PathVariable String salary, @PathVariable String date) {
        LOG.debug("Received compensation create request for employee [{}] and salary [{}] and date [{}]", employee, salary, date);
        return employeeService.createComp(employee, salary, date);
    }
}
