// Source code is decompiled from a .class file using FernFlower decompiler.
package com.mindex.challenge.data;
// package com.mindex.challenge.service.impl;
//taken from databoostrap test
// package com.mindex.challenge;

import java.util.List;
import java.util.ArrayList;
import com.mindex.challenge.data.Employee;
import com.mindex.challenge.service.EmployeeService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//taken from databoostrap test
import com.mindex.challenge.dao.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//

public class ReportingStructure{
   private static final Logger LOG = LoggerFactory.getLogger(ReportingStructure.class);


   private EmployeeRepository employeeRepository;
   private Employee employee; 
   private int numberOfReports;
   
   private List<Employee> directReports;

   public ReportingStructure(EmployeeRepository repo) {
      employeeRepository = repo; 
      directReports = new ArrayList<>(); 
   }

   public Employee getEmployee() {
      return employee;
   }
 
   public void setEmployee(Employee employee) {
      this.employee = employee;
   }

   public int getNumberOfReports() {
      return numberOfReports;
   }

   public int setNumberOfReports() {
      //create empty list to be filled in the search phase
      List<Employee> reportsList = new ArrayList<>();
		//in the parent employee id, recursively check if there are any direct reports and add one for each. 
		directReports = calculateReportingNumber(employee, reportsList); 
      LOG.debug("final direct reports list: {}", directReports);
      numberOfReports = directReports.size(); 
      return numberOfReports; 
		
   }

   private Employee getEmployeeById(String id){
      return  employeeRepository.findByEmployeeId(id);
   }
    
   /*
    * this method will recursively generate a list of all the direct reports for the given employee. The return will be the generated list.
    */
   private List<Employee> calculateReportingNumber(Employee employee, List<Employee> totalReportsList){
     
      LOG.debug("we in here with employee [{}]", employee.getFirstName());
		//get the direct reports about the employee
		List<Employee> currentReportsList = employee.getDirectReports();
      LOG.debug("current reports list generated: {}", currentReportsList);
      
      //if this employee has reports
      if(currentReportsList != null && currentReportsList.size() > 0){
         LOG.debug("[{}] had [{}] direct reports", employee.getFirstName(), currentReportsList.size());
         //if the input employeeID has a direct report, go through each of them 
         for(int i=0; i<currentReportsList.size(); i++){
            //current reports is then just a list of employee ids
            Employee currentReportRef = currentReportsList.get(i); 

            String directReportId = currentReportRef.getEmployeeId();
            LOG.debug("current report id: {}", directReportId);
            Employee currentReport = getEmployeeById(directReportId); 

            LOG.debug("Report number {} name is {} {}, id {}",i,  currentReport.getFirstName(), currentReport.getLastName(), currentReport.getEmployeeId());
            //add to total reports list
            totalReportsList.add(currentReport);
            LOG.debug("reports list is: {}", totalReportsList);
            // return reports + calculateReportingNumber(currentReport, reports, totalReportsList);
            calculateReportingNumber(currentReport,  totalReportsList);
         }
         return totalReportsList; 
      }else{
         //return the number
         LOG.debug("[{}] had no direct reports", employee);
         return totalReportsList; 
      }//else
   }//calculateReportingNumber
}
