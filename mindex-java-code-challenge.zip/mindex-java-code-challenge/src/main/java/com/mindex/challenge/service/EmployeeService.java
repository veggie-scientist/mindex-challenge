package com.mindex.challenge.service;

import com.mindex.challenge.data.Employee;
import com.mindex.challenge.data.ReportingStructure; //AV
import com.mindex.challenge.data.Compensation;  //av task 2



public interface EmployeeService {
    Employee create(Employee employee);
    Employee read(String id);
    Employee update(Employee employee);
    //AV task 1
    ReportingStructure directReports(String id);

    //AV task 2
    Compensation createComp(Employee employee, String salary, String date);
    Compensation readComp(String id);
}
