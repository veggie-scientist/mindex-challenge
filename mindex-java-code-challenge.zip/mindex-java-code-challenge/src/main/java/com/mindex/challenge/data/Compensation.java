package com.mindex.challenge.data;
import java.util.List;

public class Compensation {
    private String employeeId;  //required employee id will be used as the key for db storage
    private Employee employee; 
    private String salary; 
    private String effectiveDate; 


    public Compensation() {
    }

    public Employee getEmployee(){
        return employee;
    }

    public void setEmployee(Employee employee){
        this.employee = employee; 
    }

    public String getSalary(){
        return salary; 
    }

    public void setSalary(String salary){
        this.salary = salary; 
    }

    public String geteffectiveDate(){
        return effectiveDate; 
    }

    public void seteffectiveDate(String date){
        this.effectiveDate = date; 
    }

   //emp id
    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }
}
